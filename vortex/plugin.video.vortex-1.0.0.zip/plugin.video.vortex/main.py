#HLS/HTTP/Secure/Plex/Int/Compact
import sys,urllib.request,urllib.parse,urllib.error,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,re,time,json,os,base64,xml.etree.ElementTree as ET,hashlib
from datetime import datetime,timedelta
try: import inputstreamhelper; HAS_INPUTSTREAM_HELPER = True
except: HAS_INPUTSTREAM_HELPER = False
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
PLUGIN_KEY = "plugin.video.vortex"
HANDLE = int(sys.argv[1])
TOKEN_CACHE_DIR = xbmcvfs.translatePath(f"special://userdata/addon_data/{ADDON_ID}/tokens/")
TOKEN_CACHE_FILE = os.path.join(TOKEN_CACHE_DIR, "token_cache.json")
def verify_addon_id():
    try: return ET.parse(os.path.join(ADDON_PATH,'addon.xml')).getroot().get('id','') == ADDON_ID
    except: return False
if not verify_addon_id(): sys.exit()
ADDON_ICON = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/icon.png")
ADDON_FANART = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/fanart.jpg")
CACHE_DIR = xbmcvfs.translatePath(f"special://userdata/addon_data/{ADDON_ID}/")
CACHE_FILE = os.path.join(CACHE_DIR, "playlist_cache.dat")
FAVOURITES_FILE = os.path.join(CACHE_DIR, "encrypted_favourites.dat")
XOR_KEY = b"k5F9#mR2@qW8!zX0$vB7%nC1^aD3&sE4*lG6(jH0)pK9_yL2"
PLAYLIST_SOURCES = {
    "Plex TV": "https://raw.githubusercontent.com/BuddyChewChew/plex/refs/heads/main/playlists/plex_gb.m3u",
    "Rakuten TV": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/uk_rakuten.m3u",
    "Roku TV": "https://raw.githubusercontent.com/BuddyChewChew/roku-playlist-generator/refs/heads/main/roku.m3u",
    "Samsung TV": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/refs/heads/main/playlists/samsungtvplus_gb.m3u",
    "Tubi TV": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us_tubi.m3u",
    "TV Pass": "https://raw.githubusercontent.com/BuddyChewChew/buddylive_v2/refs/heads/main/en/videoall.m3u",
    "US TV": "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/us.m3u",
    "Xumo TV": "https://raw.githubusercontent.com/BuddyChewChew/xumo-playlist-generator/refs/heads/main/playlists/xumo_playlist.m3u"
}
BLOCKED_KEYWORDS = ["gettv","mlb","nba","nfl","nhl","ppv","sky arts","sky mix","sportsman","pluto","&TV","[Not 24/7]","[Geo-blocked]","Fox News Channel","FETV","Opportunities","Village of Hastings-On-Hudson NY (WHOH-TV)","WVCU-LP Concord University Radio The Cure 97.7","24Kitchen Serbia","6 Wise Tv","vs","New K.Movies","RomCom K-Drama","Lighting Lives","iHeart"]
TITLE_BLOCK_PATTERNS = [r'\([^)]*\)',r'\[[^\]]*\]']
CACHE_DURATION = 12 * 60 * 60
MAX_TITLE_LENGTH = 40
TOKEN_VALIDITY = 3600
seen_titles_global = set()
def log(message, level=xbmc.LOGINFO): xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)
def ensure_token_cache_dir():
    if not xbmcvfs.exists(TOKEN_CACHE_DIR): xbmcvfs.mkdirs(TOKEN_CACHE_DIR)
def load_token_cache():
    ensure_token_cache_dir()
    if not xbmcvfs.exists(TOKEN_CACHE_FILE): return {}
    try:
        with open(TOKEN_CACHE_FILE,'r') as f: return json.load(f)
    except Exception as e: log(f"Error loading token cache: {str(e)}", xbmc.LOGWARNING); return {}
def save_token_cache(token_data):
    try:
        ensure_token_cache_dir()
        with open(TOKEN_CACHE_FILE,'w') as f: json.dump(token_data,f)
    except Exception as e: log(f"Error saving token cache: {str(e)}", xbmc.LOGWARNING)
def get_cached_token(channel_id):
    token_cache = load_token_cache()
    if channel_id in token_cache and time.time()-token_cache[channel_id].get('timestamp',0) < token_cache[channel_id].get('validity',TOKEN_VALIDITY): return token_cache[channel_id].get('token')
    return None
def cache_token(channel_id, token, validity=TOKEN_VALIDITY):
    token_cache = load_token_cache()
    token_cache[channel_id] = {'token':token,'timestamp':time.time(),'validity':validity}
    save_token_cache(token_cache)
def extract_channel_id_from_url(url):
    try:
        m=re.search(r'/parts/([a-f0-9]{24})-',url)
        if m: return m.group(1)
        m=re.search(r'/(\d+)/',url)
        if m: return f"channel_{m.group(1)}"
        return hashlib.md5(url.encode()).hexdigest()[:16]
    except: return "unknown"
def extract_token_from_url(url):
    try:
        p=urllib.parse.urlparse(url)
        params=urllib.parse.parse_qs(p.query)
        return params['X-Plex-Token'][0] if 'X-Plex-Token' in params else None
    except: return None
def ensure_cache_dir():
    if not xbmcvfs.exists(CACHE_DIR): xbmcvfs.mkdirs(CACHE_DIR)
def xor_encrypt_decrypt(data):
    if XOR_KEY is None: log("XOR_KEY not initialized!", xbmc.LOGERROR); return data
    return bytes([data[i]^XOR_KEY[i%len(XOR_KEY)] for i in range(len(data))])
def encrypt_favourite_url(url):
    return base64.b64encode(xor_encrypt_decrypt(url.encode('utf-8'))).decode('utf-8')
def decrypt_favourite_url(encrypted_url):
    try: return xor_encrypt_decrypt(base64.b64decode(encrypted_url.encode('utf-8'))).decode('utf-8')
    except Exception as e: log(f"Error decrypting favourite URL: {str(e)}", xbmc.LOGERROR); return None
def load_cache():
    ensure_cache_dir()
    if not xbmcvfs.exists(CACHE_FILE): return {}
    try:
        with open(CACHE_FILE,'rb') as f: encrypted_data=f.read()
        if not encrypted_data: return {}
        cache_data=json.loads(xor_encrypt_decrypt(encrypted_data).decode('utf-8'))
        current_time=time.time()
        cleaned={}
        for s,c in cache_data.items():
            if current_time-c.get('timestamp',0)<=CACHE_DURATION: cleaned[s]=c
        if len(cleaned)!=len(cache_data): save_cache(cleaned)
        return cleaned
    except Exception as e: log(f"Error loading cache: {str(e)}", xbmc.LOGERROR); return {}
def save_cache(cache_data):
    try:
        ensure_cache_dir()
        with open(CACHE_FILE,'wb') as f: f.write(xor_encrypt_decrypt(json.dumps(cache_data).encode('utf-8')))
    except Exception as e: log(f"Error saving cache: {str(e)}", xbmc.LOGERROR)
def get_cached_channels(source_name):
    cache=load_cache()
    if source_name in cache and time.time()-cache[source_name].get('timestamp',0)<=CACHE_DURATION: return cache[source_name].get('channels',[])
    return None
def cache_channels(source_name, channels):
    c=load_cache(); c[source_name]={'timestamp':time.time(),'channels':channels}; save_cache(c)
def clear_cache():
    f=[]
    if xbmcvfs.exists(CACHE_FILE): xbmcvfs.delete(CACHE_FILE); f.append("Playlist cache")
    if xbmcvfs.exists(TOKEN_CACHE_FILE): xbmcvfs.delete(TOKEN_CACHE_FILE); f.append("Token cache")
    return bool(f)
def get_url(**kwargs): return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"
def get_encrypted_play_url(url): return get_url(action='play_encrypted', encrypted_url=encrypt_favourite_url(url))
def contains_blocked_keywords(t): return any(k.lower() in (t or '').lower() for k in BLOCKED_KEYWORDS) if t else False
def contains_ascii_characters(t):
    if not t: return False
    try: t.encode('ascii'); return False
    except: return True
def contains_at_character(t): return '@' in (t or '')
def contains_blocked_patterns(t): return any(re.search(p,(t or '')) for p in TITLE_BLOCK_PATTERNS) if t else False
def exceeds_character_limit(t): return len((t or '').strip())>MAX_TITLE_LENGTH
def should_skip_channel(t):
    if not t: return True
    if contains_blocked_keywords(t) or contains_ascii_characters(t) or contains_at_character(t) or contains_blocked_patterns(t) or exceeds_character_limit(t): return True
    sp=[r'^\d{1,2}:\d{2}',r'^\d{4}-\d{2}-\d{2}',r'https?://',r'\.(jpg|jpeg|png|gif|bmp|webp)$',r'^\s*$']
    tl=t.lower() if t else ""
    if any(re.search(p,tl) for p in sp): return True
    if len(t.strip())<3: return True
    return False
def clean_title(t):
    if not t: return t
    t=re.sub(r'\([^)]*\)','',t); t=re.sub(r'\[[^\]]*\]','',t)
    t=re.sub(r'\.(ts|m3u8|mp4|avi|mkv|jpg|jpeg|png|gif)$','',t,flags=re.IGNORECASE)
    t=re.sub(r'\[[^\]]*?(?:HD|SD|FHD|UHD|4K|1080|720|480)[^\]]*?\]','',t,flags=re.IGNORECASE)
    t=re.sub(r'\([^\)]*?(?:HD|SD|FHD|UHD|4K|1080|720|480)[^\)]*?\)','',t,flags=re.IGNORECASE)
    t=re.sub(r'\b(?:HD|SD|FHD|UHD|4K|1080p|720p|480p)\b','',t,flags=re.IGNORECASE)
    return re.sub(r'\s+',' ',t).strip()
def get_stream_headers(url, ah=None):
    h={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','Accept':'*/*','Accept-Language':'en-US,en;q=0.9','Connection':'keep-alive','Cache-Control':'no-cache','Pragma':'no-cache','DNT':'1'}
    if 'plex.tv' in (url or '').lower():
        h.update({'X-Plex-Client-Identifier':ADDON_ID,'X-Plex-Product':ADDON_NAME,'X-Plex-Version':ADDON_VERSION,'X-Plex-Device':'Kodi','X-Plex-Device-Name':'Kodi Media Player','X-Plex-Platform':'Kodi','X-Plex-Platform-Version':'20.0','Accept-Encoding':'identity','Referer':'https://app.plex.tv/','Origin':'https://app.plex.tv'})
    t=extract_token_from_url(url)
    if t: h['X-Plex-Token']=t
    if ah: h.update(ah)
    return h
def fetch_playlist_content(url,r=3):
    for a in range(r):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers=get_stream_headers(url)),timeout=20) as resp:
                if resp.status==200: return resp.read().decode('utf-8')
                elif resp.status==401: log(f"Auth failed {url}", xbmc.LOGWARNING); return None
                else: log(f"HTTP {resp.status} for {url}", xbmc.LOGWARNING)
        except urllib.error.HTTPError as e:
            if e.code==401: log(f"Token auth failed: {str(e)}", xbmc.LOGWARNING); return None
            elif a<r-1: time.sleep(1); continue
            else: log(f"HTTP error: {str(e)}", xbmc.LOGERROR); return None
        except Exception as e:
            if a<r-1: time.sleep(1); continue
            else: log(f"Error: {str(e)}", xbmc.LOGERROR); return None
        if a<r-1: time.sleep(1)
    return None
def parse_m3u_playlist(c,sn=""):
    if not c: return []
    ch=[]; cur={}; lines=c.split('\n')
    for l in lines:
        l=l.strip()
        if not l or l.startswith('#EXTM3U') or l.startswith('#EXTVLCOPT'): continue
        if l.startswith('#EXTINF:'):
            p=l.split(',',1)
            if len(p)>1:
                t=clean_title(p[1].strip())
                if should_skip_channel(t): cur={}; continue
                cur={'title':t,'source':sn}
        elif (l.startswith('http') or l.startswith('https')) and cur:
            cid=extract_channel_id_from_url(l)
            cur['channel_id']=cid
            tok=extract_token_from_url(l)
            if tok and cid: cache_token(cid,tok)
            cur['url']=l; cur['thumbnail']=ADDON_ICON; cur['fanart']=ADDON_FANART
            ch.append(cur); cur={}
    return ch
def get_channels_from_source(sn,fr=False):
    global seen_titles_global
    seen_titles_global=set()
    if not fr:
        cc=get_cached_channels(sn)
        if cc is not None: return cc
    if sn not in PLAYLIST_SOURCES: return []
    c=fetch_playlist_content(PLAYLIST_SOURCES[sn])
    if c:
        ch=parse_m3u_playlist(c,sn); fc=[]
        for i in ch:
            tl=i['title'].lower()
            if any([contains_blocked_keywords(i['title']),contains_ascii_characters(i['title']),contains_at_character(i['title']),contains_blocked_patterns(i['title']),tl in seen_titles_global]): continue
            seen_titles_global.add(tl); fc.append(i)
        cache_channels(sn,fc); return fc
    else: cc=get_cached_channels(sn); return cc if cc else []
def detect_stream_type(url):
    u=url.lower()
    if 'plex.tv' in u: return ('hls','plex') if '.m3u8' in u else ('dash','plex') if '.mpd' in u else ('hls','plex')
    if 'a1xs.vip' in u: return ('hls','a1xs')
    if 'jmp2.uk' in u: return ('hls','jmp2')
    if '.m3u8' in u: return ('hls','generic')
    if '.mpd' in u: return ('dash','generic')
    if '.mp4' in u: return ('mp4','generic')
    return ('http','generic')
def setup_inputstream(li,url,st='hls',pf='generic'):
    if not HAS_INPUTSTREAM_HELPER: return False
    hs='&'.join([f'{k}={urllib.parse.quote(v)}' for k,v in get_stream_headers(url).items()])
    if st=='hls':
        ih=inputstreamhelper.Helper('hls')
        if ih.check_inputstream():
            li.setProperty('inputstream','inputstream.adaptive'); li.setProperty('inputstream.adaptive.manifest_type','hls'); li.setProperty('inputstream.adaptive.manifest_update_parameter','full'); li.setProperty('inputstream.adaptive.stream_headers',hs)
            if pf=='plex': li.setProperty('inputstream.adaptive.manifest_headers',hs); li.setProperty('inputstream.adaptive.license_flags','persistent_storage'); li.setProperty('inputstream.adaptive.license_type','com.widevine.alpha'); li.setProperty('inputstream.adaptive.adaptive_debug','true'); li.setContentLookup(False)
            elif pf=='a1xs': li.setProperty('inputstream.adaptive.manifest_headers',hs); li.setProperty('inputstream.adaptive.license_flags','persistent_storage'); li.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
            elif pf=='jmp2': li.setProperty('inputstream.adaptive.manifest_headers',hs); li.setProperty('inputstream.adaptive.stream_headers',hs); li.setContentLookup(False)
            return True
    elif st=='dash':
        ih=inputstreamhelper.Helper('mpd')
        if ih.check_inputstream():
            li.setProperty('inputstream','inputstream.adaptive'); li.setProperty('inputstream.adaptive.manifest_type','mpd'); li.setProperty('inputstream.adaptive.stream_headers',hs)
            if pf=='plex': li.setProperty('inputstream.adaptive.license_flags','persistent_storage'); li.setProperty('inputstream.adaptive.license_type','com.widevine.alpha')
            return True
    return False
def play_channel(url):
    try:
        st,pf=detect_stream_type(url)
        if pf=='plex':
            cid=extract_channel_id_from_url(url)
            if cid:
                ct=get_cached_token(cid)
                if ct:
                    p=urllib.parse.urlparse(url); q=urllib.parse.parse_qs(p.query); q['X-Plex-Token']=ct
                    url=urllib.parse.urlunparse((p.scheme,p.netloc,p.path,p.params,urllib.parse.urlencode(q,doseq=True),p.fragment))
        h=get_stream_headers(url); li=xbmcgui.ListItem(path=url); li.setProperty('IsPlayable','true')
        if st=='hls': li.setMimeType('application/vnd.apple.mpegurl'); li.setContentLookup(False)
        elif st=='dash': li.setMimeType('application/dash+xml')
        else: li.setMimeType('video/mp4')
        if not setup_inputstream(li,url,st,pf) and st=='hls': li.setPath(f"{url}|{'&'.join([f'{k}={urllib.parse.quote(v)}' for k,v in h.items()])}")
        hs='&'.join([f'{k}={urllib.parse.quote(v)}' for k,v in h.items()])
        li.setProperty('inputstream.adaptive.stream_headers',hs)
        if pf=='plex': li.setProperty('inputstream.adaptive.license_flags','persistent_storage'); li.setProperty('inputstream.adaptive.license_type','com.widevine.alpha'); li.setProperty('inputstream.adaptive.adaptive_debug','true')
        xbmcplugin.setResolvedUrl(HANDLE,True,li); return True
    except Exception as e: log(f"Playback error: {str(e)}", xbmc.LOGERROR); xbmcgui.Dialog().ok('Playback Error',f'Unable to play stream: {str(e)}','The stream may be unavailable or require special handling.'); xbmcplugin.setResolvedUrl(HANDLE,False,xbmcgui.ListItem()); return False
def play_encrypted_channel(encrypted_url):
    du=decrypt_favourite_url(encrypted_url)
    if du: return play_channel(du)
    else: xbmcgui.Dialog().ok('Error','Could not decrypt stream URL.'); return False
def save_custom_favourite(ct,cu,sn):
    ensure_cache_dir(); f=load_custom_favourites(); fid=f"{sn}_{ct}_{int(time.time())}"
    cid=extract_channel_id_from_url(cu); tok=extract_token_from_url(cu)
    if tok and cid: cache_token(cid,tok)
    f[fid]={'title':ct,'encrypted_url':encrypt_favourite_url(cu),'source':sn,'channel_id':cid,'thumbnail':ADDON_ICON,'fanart':ADDON_FANART,'timestamp':time.time(),'last_updated':time.time()}
    try:
        with open(FAVOURITES_FILE,'w') as fh: json.dump(f,fh)
        return True
    except Exception as e: log(f"Error saving favourite: {str(e)}", xbmc.LOGERROR); return False
def load_custom_favourites():
    if not xbmcvfs.exists(FAVOURITES_FILE): return {}
    try:
        with open(FAVOURITES_FILE,'r') as f: return json.load(f)
    except Exception as e: log(f"Error loading favourites: {str(e)}", xbmc.LOGERROR); return {}
def remove_custom_favourite(fid):
    f=load_custom_favourites()
    if fid in f: del f[fid]
    try:
        with open(FAVOURITES_FILE,'w') as fh: json.dump(f,fh)
        return True
    except Exception as e: log(f"Error removing favourite: {str(e)}", xbmc.LOGERROR); return False
def update_favourite_urls():
    f=load_custom_favourites(); uc=0
    for fid,fav in f.items():
        sn=fav.get('source'); ct=fav.get('title'); cid=fav.get('channel_id')
        if not sn or not ct: continue
        cc=get_channels_from_source(sn,False)
        mc=None
        for ch in cc:
            if ch.get('title')==ct: mc=ch; break
        if mc and mc.get('url'):
            nu=mc['url']; ce=fav.get('encrypted_url'); cd=decrypt_favourite_url(ce) if ce else None
            if nu!=cd:
                if cid:
                    nt=extract_token_from_url(nu)
                    if nt: cache_token(cid,nt)
                f[fid]['encrypted_url']=encrypt_favourite_url(nu); f[fid]['last_updated']=time.time(); uc+=1
    if uc>0:
        try:
            with open(FAVOURITES_FILE,'w') as fh: json.dump(f,fh)
        except Exception as e: log(f"Error updating favourites: {str(e)}", xbmc.LOGERROR)
    return uc
def get_smart_favourite_url(fav):
    eu=fav.get('encrypted_url')
    if eu:
        du=decrypt_favourite_url(eu)
        if du:
            cid=fav.get('channel_id')
            if cid:
                ct=get_cached_token(cid)
                if ct:
                    p=urllib.parse.urlparse(du); q=urllib.parse.parse_qs(p.query); q['X-Plex-Token']=ct
                    du=urllib.parse.urlunparse((p.scheme,p.netloc,p.path,p.params,urllib.parse.urlencode(q,doseq=True),p.fragment))
            return du
    return None
def show_custom_favourites():
    update_favourite_urls(); f=load_custom_favourites()
    if not f: xbmcgui.Dialog().ok('No Favourites','You haven\'t added any favourites yet.'); return
    for fid,fav in f.items():
        t=fav.get('title','Unknown Channel'); s=fav.get('source','Unknown Source'); lu=fav.get('last_updated',0); cu=get_smart_favourite_url(fav)
        if not cu: t=f"[COLOR red]{t} (Broken)"
        li=xbmcgui.ListItem(label=t)
        li.setArt({'thumb':fav.get('thumbnail',ADDON_ICON),'icon':fav.get('thumbnail',ADDON_ICON),'fanart':fav.get('fanart',ADDON_FANART)})
        pl=f'Favourite: {t}\nSource: {s}\nLast Updated: {time.strftime("%Y-%m-%d %H:%M",time.localtime(lu))}'
        if not cu: pl+='\n[COLOR red]URL not found in current source'
        li.setInfo('video',{'title':t,'plot':pl,'genre':'Favourite'})
        if cu: li.setProperty('IsPlayable','true')
        li.addContextMenuItems([('Remove Favourite',f'RunPlugin({get_url(action="remove_favourite",fav_id=fid)})'),('Update This Favourite',f'RunPlugin({get_url(action="update_single_favourite",fav_id=fid)})'),('Refresh Token',f'RunPlugin({get_url(action="refresh_token",fav_id=fid)})')])
        xbmcplugin.addDirectoryItem(HANDLE,get_url(action='play_favourite',encrypted_url=fav.get('encrypted_url')) if cu else get_url(action='noop'),li,isFolder=False)
    xbmcplugin.setContent(HANDLE,'videos'); xbmcplugin.endOfDirectory(HANDLE)
def update_single_favourite(fid):
    f=load_custom_favourites()
    if fid not in f: return False
    fav=f[fid]; sn=fav.get('source'); ct=fav.get('title'); cid=fav.get('channel_id')
    cc=get_channels_from_source(sn,True); mc=None
    for ch in cc:
        if ch.get('title')==ct: mc=ch; break
    if mc and mc.get('url'):
        nu=mc['url']
        if cid:
            nt=extract_token_from_url(nu)
            if nt: cache_token(cid,nt)
        f[fid]['encrypted_url']=encrypt_favourite_url(nu); f[fid]['last_updated']=time.time()
        try:
            with open(FAVOURITES_FILE,'w') as fh: json.dump(f,fh)
            return True
        except Exception as e: log(f"Error updating single favourite: {str(e)}", xbmc.LOGERROR)
    return False
def refresh_token_for_favourite(fid):
    f=load_custom_favourites()
    if fid not in f: return False
    cid=f[fid].get('channel_id')
    if cid:
        tc=load_token_cache()
        if cid in tc: del tc[cid]; save_token_cache(tc)
        xbmcgui.Dialog().notification('Token Refreshed','Token will be refreshed on next play',ADDON_ICON,3000)
        return True
    return False
def play_encrypted_favourite(eu):
    du=decrypt_favourite_url(eu)
    if du: return play_channel(du)
    else: xbmcgui.Dialog().ok('Error','Could not decrypt favourite URL. It may be corrupted.'); return False
def show_landing_page():
    global seen_titles_global; seen_titles_global=set()
    for sn in PLAYLIST_SOURCES.keys():
        li=xbmcgui.ListItem(label=sn)
        li.setArt({'thumb':ADDON_ICON,'icon':ADDON_ICON,'fanart':ADDON_FANART})
        li.setInfo('video',{'title':sn,'plot':f'Browse channels from {sn} only'})
        xbmcplugin.addDirectoryItem(HANDLE,get_url(action='source',source=sn),li,isFolder=True)
    li=xbmcgui.ListItem(label="My Favourites")
    li.setArt({'thumb':ADDON_ICON,'icon':ADDON_ICON,'fanart':ADDON_FANART})
    li.setInfo('video',{'title':'Vortex Favourites','plot':'Your saved favourite channels'})
    xbmcplugin.addDirectoryItem(HANDLE,get_url(action='show_favourites'),li,isFolder=True)
    li=xbmcgui.ListItem(label="Refresh Lists")
    li.setArt({'thumb':ADDON_ICON,'icon':ADDON_ICON,'fanart':ADDON_FANART})
    li.setInfo('video',{'title':'Refresh Playlists And Clear Cache','plot':'Clear playlist and token cache'})
    xbmcplugin.addDirectoryItem(HANDLE,get_url(action='clear_cache'),li,isFolder=False)
    xbmcplugin.setContent(HANDLE,'files'); xbmcplugin.endOfDirectory(HANDLE)
def list_source_channels(sn,fr=False):
    ch=get_channels_from_source(sn,fr)
    if not ch: xbmcgui.Dialog().ok('Error',f'No channels found from {sn}. Please check your internet connection and try again.'); xbmcplugin.endOfDirectory(HANDLE); return
    ch.sort(key=lambda x: x['title'].lower())
    for c in ch:
        t=c.get('title','Unknown Channel'); u=c.get('url',''); cid=c.get('channel_id',''); th=c.get('thumbnail',ADDON_ICON)
        li=xbmcgui.ListItem(label=t)
        li.setArt({'thumb':th,'icon':th,'fanart':ADDON_FANART})
        st,pf=detect_stream_type(u)
        li.setInfo('video',{'title':t,'plot':f'Live TV Channel: {t}\nSource: {sn}\nStream Type: {st.upper()}'})
        li.setProperty('IsPlayable','true')
        cm=[('Add To My Favourites',f'RunPlugin({get_url(action="add_favourite",title=urllib.parse.quote(t),url=urllib.parse.quote(u),source=sn)})')]
        if pf=='plex' and cid: cm.append(('Refresh Token',f'RunPlugin({get_url(action="refresh_channel_token",channel_id=cid)})'))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(HANDLE,get_encrypted_play_url(u),li,isFolder=False)
    xbmcplugin.setContent(HANDLE,'videos'); xbmcplugin.endOfDirectory(HANDLE)
def refresh_channel_token(cid):
    tc=load_token_cache()
    if cid in tc: del tc[cid]; save_token_cache(tc); xbmcgui.Dialog().notification('Token Refreshed','Channel token will be refreshed',ADDON_ICON,3000)
    return True
def router(params):
    a=params.get('action',''); u=params.get('url',''); s=params.get('source',''); fr=params.get('refresh','')=='true'; fid=params.get('fav_id',''); eu=params.get('encrypted_url',''); t=params.get('title',''); cid=params.get('channel_id','')
    if a=='play' and u: play_channel(urllib.parse.unquote(u))
    elif a=='play_encrypted' and eu: play_encrypted_channel(eu)
    elif a=='play_favourite' and eu: play_encrypted_favourite(eu)
    elif a=='source' and s: list_source_channels(s,fr)
    elif a=='clear_cache':
        if clear_cache(): xbmcgui.Dialog().ok('Information','Playlists refreshed and all caches cleared.\n\nYour favourites have been preserved.')
        show_landing_page()
    elif a=='show_favourites': show_custom_favourites()
    elif a=='add_favourite' and u and t: save_custom_favourite(urllib.parse.unquote(t),urllib.parse.unquote(u),s); xbmcgui.Dialog().notification('Favourite Added',f'Added {urllib.parse.unquote(t)} to favourites',ADDON_ICON,3000)
    elif a=='remove_favourite' and fid:
        if remove_custom_favourite(fid): xbmcgui.Dialog().notification('Favourite Removed','Favourite removed successfully',ADDON_ICON,3000)
        show_custom_favourites()
    elif a=='update_single_favourite' and fid: update_single_favourite(fid); show_custom_favourites()
    elif a=='refresh_token' and fid: refresh_token_for_favourite(fid); show_custom_favourites()
    elif a=='refresh_channel_token' and cid: refresh_channel_token(cid); xbmc.executebuiltin('Container.Refresh')
    elif a=='noop': pass
    else: show_landing_page()
if __name__ == '__main__':
    router(dict(urllib.parse.parse_qsl(sys.argv[2][1:])))

